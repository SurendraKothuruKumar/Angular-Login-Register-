import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegistrationserviceService {

 constructor(private http:HttpClient) { }

  private baseUrl = 'http://localhost:4422/createUser';

  createUser(user:any): Observable<any>{

    console.log(user);

    console.log(user);
    return this.http.post(this.baseUrl,user);
}
}