export class User {
    id:number=0;
    userName: string='';
    emailId: string='';
    password: string='';
   
}
