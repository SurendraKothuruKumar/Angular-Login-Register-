import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginsucess',
  templateUrl: './loginsucess.component.html',
  styleUrls: ['./loginsucess.component.css']
})
export class LoginsucessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
