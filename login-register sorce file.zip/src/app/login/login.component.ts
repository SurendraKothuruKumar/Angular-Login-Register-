import { Component, OnInit } from '@angular/core';
import { LoginserviceService } from '../loginservice.service';
import { Router } from '@angular/router';
import { User } from '../user';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 registration=sessionStorage.getItem("key");
  user:User=new User();
  message='';
  constructor(private loginservice:LoginserviceService, private router:Router) { }


  ngOnInit(): void {
  }

  loginUser()
   {
     var a = this.user
    this.loginservice.loginUser(this.user)
     .subscribe(
       data => {
         console.log(data);
         this.save(data)
         sessionStorage.removeItem("key")
         this.router.navigate(['/loginsucess']);
      },
      error => {
        console.log("exception occured");
       this.message="Bad credentials, please enter valid userid and password";
     });

       }

       save(data: { lastName: string; })
       {
         this.loginservice.saveUser(data);
       }
  goToRegister()
  {
    this.router.navigate(['register']);
  }
  

}
